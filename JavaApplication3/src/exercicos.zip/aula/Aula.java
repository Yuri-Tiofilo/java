
package aula; 

public class Aula {

    public static void main(String[] args) {
       Car c1 = new Car();
       c1.ano = "2001";
       c1.nome = "fox";
       c1.ligaMotor();
       
          
    }
    
}
